self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "495d9faa7ae55ebf00aaa0875936f072",
    "url": "/freezeframe.js/react/index.html"
  },
  {
    "revision": "48e370032bab058106b7",
    "url": "/freezeframe.js/react/static/css/main.85c39dd4.chunk.css"
  },
  {
    "revision": "bb8a4a0c05535095512e",
    "url": "/freezeframe.js/react/static/js/2.7ff973e6.chunk.js"
  },
  {
    "revision": "48e370032bab058106b7",
    "url": "/freezeframe.js/react/static/js/main.7b514271.chunk.js"
  },
  {
    "revision": "84cb35a47ccb251394a0",
    "url": "/freezeframe.js/react/static/js/runtime~main.0b442b39.js"
  }
]);