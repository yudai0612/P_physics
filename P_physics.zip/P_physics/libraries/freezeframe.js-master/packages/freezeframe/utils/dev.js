const server = require('./webserver');

server(process.env.PORT);
