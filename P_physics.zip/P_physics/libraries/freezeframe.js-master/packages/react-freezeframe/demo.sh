#!/usr/bin/env bash

rm -rf ../../docs/react

cp -rf ./build ../../docs/react
