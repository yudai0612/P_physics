#!/usr/bin/env bash

rm -rf ../../docs/vue

cp -rf ./demo ../../docs/vue
