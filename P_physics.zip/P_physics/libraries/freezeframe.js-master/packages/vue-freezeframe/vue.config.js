module.exports = {
  publicPath: '/freezeframe.js/vue/',
};
